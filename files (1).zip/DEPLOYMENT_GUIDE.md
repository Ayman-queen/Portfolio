# 🚀 FULL-STACK PORTFOLIO DEPLOYMENT GUIDE

## 📦 **What You Have:**

1. **FastAPI Backend** (Python) - `/backend/main.py`
2. **SQLite Database** - Auto-created
3. **Dynamic Frontend** - `/frontend/index-dynamic.html`
4. **Requirements** - `/backend/requirements.txt`

---

## 🏗️ **ARCHITECTURE OVERVIEW**

```
┌─────────────────┐
│   Frontend      │
│  (HTML/CSS/JS)  │
│   Port: 3000    │
└────────┬────────┘
         │ Fetch API
         ▼
┌─────────────────┐
│  FastAPI Server │
│    (Python)     │
│   Port: 8000    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ SQLite Database │
│ (portfolio.db)  │
└─────────────────┘
```

---

## 🖥️ **LOCAL DEVELOPMENT (Your Computer)**

### Step 1: Setup Backend

```bash
# Navigate to backend folder
cd backend

# Install Python dependencies
pip install -r requirements.txt

# Run FastAPI server
python main.py

# Server starts at: http://localhost:8000
# API Docs at: http://localhost:8000/docs
```

### Step 2: Setup Frontend

```bash
# Navigate to frontend folder
cd frontend

# Option 1: Python HTTP Server
python -m http.server 3000

# Option 2: Node.js HTTP Server
npx http-server -p 3000

# Option 3: VS Code Live Server extension
# Right-click index-dynamic.html → Open with Live Server
```

### Step 3: Access Your Portfolio

- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:8000
- **API Docs:** http://localhost:8000/docs (Interactive Swagger UI)

---

## ☁️ **CLOUD DEPLOYMENT**

### Option 1: Vercel (Frontend) + Railway (Backend)

**Deploy Backend to Railway:**

1. Create account: https://railway.app
2. New Project → Deploy from GitHub
3. Select your repo
4. Railway auto-detects Python
5. Add environment variables if needed
6. Get your backend URL: `https://your-app.railway.app`

**Deploy Frontend to Vercel:**

1. Update API_BASE_URL in frontend:
   ```javascript
   const API_BASE_URL = 'https://your-app.railway.app/api';
   ```
2. Deploy to Vercel:
   ```bash
   npm i -g vercel
   vercel --prod
   ```

### Option 2: Render (Full-Stack)

**Deploy Backend:**

1. Go to https://render.com
2. New → Web Service
3. Connect GitHub repo
4. Build Command: `pip install -r requirements.txt`
5. Start Command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
6. Get URL: `https://your-app.onrender.com`

**Deploy Frontend:**

1. New → Static Site
2. Build Command: (leave empty)
3. Publish Directory: `frontend`
4. Update API_BASE_URL in code
5. Deploy!

### Option 3: Heroku (Traditional)

```bash
# Install Heroku CLI
# Add Procfile to backend/
echo "web: uvicorn main:app --host 0.0.0.0 --port $PORT" > Procfile

# Deploy
heroku create your-portfolio-api
git push heroku main
```

### Option 4: Replit (Easiest!)

1. Import to Replit
2. Select Python
3. Replit auto-detects requirements.txt
4. Click "Run"
5. Share the URL!

---

## 📱 **MOBILE DEPLOYMENT (From Phone)**

### Using Replit Mobile:

1. **Install Replit App** (iOS/Android)
2. **Create New Repl:**
   - Language: Python
   - Template: FastAPI
3. **Upload Files:**
   - Upload main.py
   - Upload requirements.txt
4. **Run:**
   - Tap "Run" button
   - Get live URL instantly
5. **Frontend:**
   - Create HTML repl
   - Upload index-dynamic.html
   - Update API_BASE_URL
   - Deploy!

---

## 🗄️ **DATABASE OPTIONS**

### Current: SQLite (Auto-created)
- ✅ Zero config
- ✅ File-based
- ❌ Not ideal for production

### Upgrade Options:

**1. PostgreSQL (Recommended for Production)**

```python
# Install: pip install psycopg2-binary databases
# Update connection in main.py:

from databases import Database

DATABASE_URL = "postgresql://user:password@host:5432/dbname"
database = Database(DATABASE_URL)
```

**Free PostgreSQL Hosting:**
- Supabase: https://supabase.com (Free tier)
- Railway: https://railway.app (Free tier)
- ElephantSQL: https://elephantsql.com (Free tier)

**2. MongoDB**

```python
# Install: pip install motor
from motor.motor_asyncio import AsyncIOMotorClient

client = AsyncIOMotorClient("mongodb://...")
db = client.portfolio
```

---

## 🔐 **SECURITY (Production)**

### Add Authentication:

```python
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer

security = HTTPBearer()

async def verify_token(credentials = Depends(security)):
    token = credentials.credentials
    if token != "your-secret-token":
        raise HTTPException(status_code=401, detail="Invalid token")
    return token

@app.post("/api/projects")
async def create_project(project: Project, token = Depends(verify_token)):
    # Only accessible with valid token
    pass
```

### Environment Variables:

```python
# .env file
DATABASE_URL=postgresql://...
SECRET_KEY=your-secret-key
ALLOWED_ORIGINS=https://yoursite.com

# Load in main.py
from dotenv import load_dotenv
load_dotenv()

ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")
```

---

## 📊 **API ENDPOINTS AVAILABLE**

### Projects:
- `GET /api/projects` - Get all projects
- `GET /api/projects?category=web` - Filter by category
- `GET /api/projects/{id}` - Get single project
- `POST /api/projects` - Create project (Admin)

### Skills:
- `GET /api/skills` - Get all skills
- `GET /api/skills?category=Frontend` - Filter by category

### Contact:
- `POST /api/contact` - Submit contact form
- `GET /api/contact/messages` - Get all messages (Admin)

### Analytics:
- `POST /api/analytics` - Log event
- `GET /api/analytics/stats` - Get statistics

### Health:
- `GET /api/health` - Check server status

---

## 🧪 **TESTING THE API**

### Using Browser:
- Visit: http://localhost:8000/docs
- Interactive Swagger UI
- Test all endpoints

### Using cURL:

```bash
# Get projects
curl http://localhost:8000/api/projects

# Submit contact form
curl -X POST http://localhost:8000/api/contact \
  -H "Content-Type: application/json" \
  -d '{"name":"Test","email":"test@example.com","message":"Hello!"}'

# Get analytics
curl http://localhost:8000/api/analytics/stats
```

### Using Python:

```python
import requests

# Get projects
response = requests.get('http://localhost:8000/api/projects')
projects = response.json()
print(projects)

# Submit message
data = {
    "name": "John Doe",
    "email": "john@example.com",
    "message": "Great portfolio!"
}
response = requests.post('http://localhost:8000/api/contact', json=data)
print(response.json())
```

---

## 🔧 **CUSTOMIZATION**

### Add New Project via API:

```python
import requests

new_project = {
    "title": "My New Project",
    "description": "An amazing project",
    "category": "web",
    "tags": ["HTML", "CSS", "JavaScript"],
    "live_url": "https://example.com",
    "code_url": "https://github.com/...",
    "featured": True
}

response = requests.post(
    'http://localhost:8000/api/projects',
    json=new_project
)
print(response.json())
```

### Add New Skill:

```python
new_skill = {
    "category": "Backend Development",
    "name": "FastAPI",
    "percentage": 85,
    "icon": "⚡"
}

response = requests.post(
    'http://localhost:8000/api/skills',
    json=new_skill
)
```

---

## 📈 **MONITORING & ANALYTICS**

### Built-in Analytics:

The backend tracks:
- Page views
- Project views
- Contact form submissions
- Outbound link clicks

### View Analytics:

```bash
curl http://localhost:8000/api/analytics/stats
```

Returns:
```json
{
  "totalVisits": 150,
  "totalMessages": 12,
  "projectViews": 45,
  "eventBreakdown": [...]
}
```

---

## 🚨 **TROUBLESHOOTING**

### Backend won't start:
```bash
# Check Python version (3.8+ required)
python --version

# Reinstall dependencies
pip install -r requirements.txt --force-reinstall

# Check port availability
lsof -i :8000  # Mac/Linux
netstat -ano | findstr :8000  # Windows
```

### Frontend can't connect:
1. Check CORS settings in main.py
2. Verify API_BASE_URL in frontend
3. Check browser console for errors
4. Ensure backend is running

### Database errors:
```bash
# Delete and recreate database
rm portfolio.db
python main.py  # Auto-creates fresh database
```

---

## 📚 **LEARNING RESOURCES**

### FastAPI:
- Official Docs: https://fastapi.tiangolo.com
- Tutorial: https://fastapi.tiangolo.com/tutorial

### SQLite:
- Browser: https://sqlitebrowser.org
- Tutorial: https://www.sqlitetutorial.net

### Deployment:
- Vercel: https://vercel.com/docs
- Railway: https://docs.railway.app
- Render: https://render.com/docs

---

## 🎯 **PRODUCTION CHECKLIST**

Before deploying to production:

- [ ] Add authentication for admin endpoints
- [ ] Set up environment variables
- [ ] Use PostgreSQL instead of SQLite
- [ ] Enable HTTPS/SSL
- [ ] Add rate limiting
- [ ] Set up error logging
- [ ] Add database backups
- [ ] Configure CORS properly
- [ ] Add monitoring (Sentry, etc.)
- [ ] Test all endpoints
- [ ] Optimize database queries
- [ ] Add caching (Redis)

---

## 💡 **WHY USE BACKEND?**

### Benefits:

1. **Dynamic Content:** Update projects without editing code
2. **Contact Forms:** Store messages in database
3. **Analytics:** Track visitor behavior
4. **Admin Panel:** Manage content via API
5. **Scalability:** Add features easily (blog, comments, etc.)
6. **SEO:** Server-side rendering possible
7. **Security:** Protect sensitive data
8. **Real-time:** WebSocket support for live updates

---

## 🚀 **NEXT STEPS**

1. **Run Locally:** Test everything works
2. **Deploy Backend:** Choose Railway/Render
3. **Deploy Frontend:** Vercel/Netlify
4. **Test Live:** Verify API connections
5. **Add Content:** Use API to add projects
6. **Monitor:** Check analytics dashboard
7. **Iterate:** Add new features!

---

**Your portfolio is now a full-stack powerhouse! 🎉**

Backend: Python FastAPI ✓
Frontend: Modern HTML/CSS/JS ✓
Database: SQLite (upgradable to PostgreSQL) ✓
API: RESTful with auto-docs ✓
Analytics: Built-in tracking ✓
Deployment: Multiple options ✓

**Ready to impress! 🌟**
